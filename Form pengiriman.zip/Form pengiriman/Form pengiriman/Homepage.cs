﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_pengiriman
{
    public partial class Homepage : Form
    {
        public Homepage()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void dataPenggunaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //data pengirim
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
           
        }
  

        private void barangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //data barang
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //transaksi pengiriman
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }
    }
}
